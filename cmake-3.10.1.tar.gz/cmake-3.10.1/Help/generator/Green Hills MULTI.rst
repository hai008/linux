Green Hills MULTI
-----------------

Generates Green Hills MULTI project files (experimental, work-in-progress).

Customizations are available through the following cache variables:

* ``GHS_BSP_NAME``
* ``GHS_CUSTOMIZATION``
* ``GHS_GPJ_MACROS``
* ``GHS_OS_DIR``

.. note::
  This generator is deemed experimental as of CMake |release|
  and is still a work in progress.  Future versions of CMake
  may make breaking changes as the generator matures.
