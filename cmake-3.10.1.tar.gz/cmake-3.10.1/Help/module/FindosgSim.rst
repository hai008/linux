.. cmake-module:: ../../Modules/FindosgSim.cmake
