.. cmake-module:: ../../Modules/FindQt.cmake
